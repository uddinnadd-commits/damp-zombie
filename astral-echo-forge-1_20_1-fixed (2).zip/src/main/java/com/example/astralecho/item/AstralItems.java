package com.example.astralecho.item;

import com.example.astralecho.AstralEcho;
import net.minecraft.world.item.Item;
import com.example.astralecho.sound.AstralSounds;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class AstralItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AstralEcho.MOD_ID);

    public static final RegistryObject<Item> ASTRAL_COMPASS = ITEMS.register("astral_compass",
            () -> new AstralCompassItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> STAR_SHARD = ITEMS.register("star_shard",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> STARBURST_WAND = ITEMS.register("starburst_wand",
            () -> new StarburstWandItem(new Item.Properties().stacksTo(1).durability(180)));
    public static final RegistryObject<Item> GROVE_SIGIL = ITEMS.register("grove_sigil",
            () -> new GroveSigilItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> STARFALL_TOTEM = ITEMS.register("starfall_totem",
            () -> new StarfallTotemItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> STARHEART = ITEMS.register("starheart",
            () -> new Item(new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> STARLIGHT_RECORD = ITEMS.register("starlight_record",
            () -> new net.minecraft.world.item.RecordItem(15, AstralSounds.MUSIC_DISC_STARLIGHT,
                    new Item.Properties().stacksTo(1), 96 * 20));
    public static final RegistryObject<Item> DEVOURER_RECORD = ITEMS.register("devourer_record",
            () -> new net.minecraft.world.item.RecordItem(15, AstralSounds.MUSIC_DISC_DEVOURER,
                    new Item.Properties().stacksTo(1), 112 * 20));

    private AstralItems() {}
}
