package com.example.astralecho.item;

import com.example.astralecho.sound.AstralSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class StarburstWandItem extends Item {
    public StarburstWandItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel server) {
            Vec3 origin = player.position().add(0, 1.0, 0);
            Vec3 look = player.getLookAngle();
            server.sendParticles(ParticleTypes.END_ROD, origin.x, origin.y, origin.z, 30, 0.15, 0.15, 0.15, 0.12);
            server.sendParticles(ParticleTypes.FIREWORK, origin.x + look.x * 2, origin.y + look.y * 2,
                    origin.z + look.z * 2, 24, 0.45, 0.45, 0.45, 0.08);
            AABB impactArea = player.getBoundingBox().expandTowards(look.scale(12)).inflate(2.2);
            for (Monster monster : level.getEntitiesOfClass(Monster.class, impactArea, Monster::isAlive)) {
                Vec3 toward = monster.position().subtract(origin);
                double forward = toward.normalize().dot(look);
                if (forward > 0.35 && monster.distanceToSqr(player) <= 196) {
                    monster.hurt(level.damageSources().playerAttack(player), 7.0F);
                    monster.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.GLOWING, 100));
                    monster.knockback(0.9, -look.x, -look.z);
                    server.sendParticles(ParticleTypes.CRIT, monster.getX(), monster.getY() + 1, monster.getZ(), 22,
                            0.45, 0.5, 0.45, 0.2);
                }
            }
            level.playSound(null, player.blockPosition(), AstralSounds.ASTRAL_BURST.get(), SoundSource.PLAYERS, 1.0F, 1.3F);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.getCooldowns().addCooldown(this, 20 * 4);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
