import numpy as np
from pathlib import Path
import wave, struct

SR=22050
OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
def write_wav(path, audio):
    audio=np.asarray(audio,dtype=np.float32)
    audio=np.clip(audio,-1,1)
    pcm=(audio*32767).astype('<i2')
    with wave.open(str(path),'wb') as f:
        f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR); f.writeframes(pcm.tobytes())

def env(t, attack=.7, release=2.2):
    return np.minimum(1,t/attack).clip(0,1)*np.minimum(1,(t[-1]-t)/release).clip(0,1)
def note(freq,t,dur,amp=.1,kind='bell',pan=0):
    x=np.zeros_like(t)
    mask=(t>=0)&(t<dur)
    q=t[mask]
    if kind=='bell':
        e=np.exp(-q*2.8)*(1-np.exp(-q*22))
        v=(np.sin(2*np.pi*freq*q)+.43*np.sin(2*np.pi*freq*2.01*q)+.18*np.sin(2*np.pi*freq*3.97*q))*e
    elif kind=='pad':
        e=np.minimum(1,q/.6)*np.minimum(1,(dur-q)/1.4).clip(0,1)
        vibr=.0018*np.sin(2*np.pi*.19*q)
        v=(np.sin(2*np.pi*freq*q+vibr)+.38*np.sin(2*np.pi*freq*1.003*q)+.16*np.sin(2*np.pi*freq*.5*q))*e
    else:
        e=np.exp(-q*3.5)
        v=(np.sin(2*np.pi*freq*q)+.22*np.sin(2*np.pi*freq*2.7*q))*e
    x[mask]=amp*v
    return x

def stereo(mono, pan=0):
    l=np.sqrt((1-pan)/2)*mono; r=np.sqrt((1+pan)/2)*mono
    return np.column_stack([l,r])

def write_ambience():
    dur=24.0; n=int(SR*dur); t=np.arange(n)/SR
    rng=np.random.default_rng(918)
    noise=rng.normal(0,1,n)
    wind=noise*.0007
    # Slow, stereo moving air and distant shimmering tree tones
    x=np.column_stack([wind*(.8+.2*np.sin(2*np.pi*t/17)), wind*(.8+.2*np.sin(2*np.pi*t/17+1.2))])
    for f,a,ph in [(110,.018,0),(165,.013,.5),(220,.009,1.3)]:
        tone=np.sin(2*np.pi*f*t+0.18*np.sin(2*np.pi*t/13+ph))*0.5
        x += stereo(tone*a, np.sin(2*np.pi*t/18+ph)*.65)
    # birdlike glass notes on the loop, matched start/end by phase-cycle design
    for start,f in [(2.5,1174.66),(8.5,1567.98),(15.0,1318.51),(20.2,1760.0)]:
        rel=(t-start)%dur
        x += stereo(note(f,rel,1.8,.018,'bell'), np.sin(2*np.pi*t/10))
    # gentle, slow breath pulse
    x *= (0.85+0.15*np.sin(2*np.pi*t/dur))[:,None]
    x=np.tanh(x*2.2)*.8
    write_wav(OUT/'grove_ambience.wav', x)

def make_track(title, dur, bpm, chords, melody, seed):
    n=int(SR*dur); t=np.arange(n)/SR; x=np.zeros((n,2),np.float64)
    beat=60/bpm; bar=beat*4
    # harmonic pad progressions
    for bi,chord in enumerate(chords):
        start=bi*bar
        if start>=dur: break
        end=min(dur,start+bar*1.02)
        ix=(t>=start)&(t<end); tt=t[ix]-start; length=end-start
        fade=np.minimum(1,tt/.8)*np.minimum(1,(length-tt)/.9).clip(0,1)
        for j,f in enumerate(chord):
            wave=(np.sin(2*np.pi*f*tt)+.28*np.sin(2*np.pi*f*2.003*tt)+.12*np.sin(2*np.pi*f*.5*tt))
            wave*=fade*(.026/(1+j*.28))
            x[ix,0]+=wave*np.sqrt(.5); x[ix,1]+=wave*np.sqrt(.5)
        # bass notes pulse every bar
        bass=chord[0]/2
        wave=np.sin(2*np.pi*bass*tt+0.03*np.sin(2*np.pi*tt/4))*fade*.045
        x[ix,0]+=wave*.7; x[ix,1]+=wave*.7
    # original motif in a gentle, sparse melody with bells
    rng=np.random.default_rng(seed)
    beat_dur=beat/2
    for i,semi in enumerate(melody):
        start=i*beat_dur
        if start>=dur: break
        # omit some beats for breath, schedule small motif gaps
        if semi is None: continue
        f=440*2**((semi-69)/12)
        rel=t-start
        pan=float(np.sin(i*1.7)*.52)
        sig=note(f,rel,min(2.3,dur-start),.105 if title=='starlit' else .085,'bell')
        x += stereo(sig,pan)
        # occasional high answering sparkle
        if i%7==3:
            x += stereo(note(f*2,rel-.13,min(1.4,dur-start),.022,'bell'),-pan)
    # slow cinematic swell and delicate shimmer
    fade=np.minimum(1,t/3)*np.minimum(1,(dur-t)/4).clip(0,1)
    x*=fade[:,None]
    # gentle echo from original phrases
    for delay,gain,pan in [(0.31,.18,-.35),(.63,.10,.35)]:
        k=int(delay*SR); x[k:]+=x[:-k]*gain
    x=np.tanh(x*1.45)*.74
    write_wav(OUT/f'music_disc_{title}.wav', x)

write_ambience()
# carefully composed in A-minor-ish / D-dorian, original melodic sequence
chords1=[[220,261.63,329.63,392],[196,246.94,293.66,349.23],[174.61,220,261.63,329.63],[196,246.94,293.66,392],
         [220,261.63,329.63,392],[261.63,329.63,392,523.25],[196,246.94,293.66,349.23],[174.61,220,261.63,329.63]]
mel1=[69,None,76,81,79,None,76,72,74,None,81,84,83,None,79,76,69,None,72,76,74,None,71,74,76,None,79,83,81,None,76,72,
      69,None,76,81,79,None,76,72,74,None,81,84,86,None,83,79,76,None,72,76,74,None,71,74,69,None,72,76,74,None,69,None]
make_track('starlight',96,72,chords1,mel1,17)
chords2=[[146.83,185,220,293.66],[164.81,196,246.94,329.63],[130.81,164.81,196,261.63],[146.83,185,220,293.66],
         [146.83,185,220,293.66],[174.61,220,261.63,349.23],[164.81,196,246.94,329.63],[130.81,164.81,196,261.63]]
mel2=[62,65,None,69,72,None,69,67,65,None,69,74,77,None,74,72,67,None,70,74,77,None,81,79,77,None,74,72,69,None,65,62,
      62,None,69,74,72,None,69,67,65,None,72,77,81,None,79,77,74,None,70,74,77,None,79,82,81,None,77,74,72,None,69,None]
make_track('devourer',112,82,chords2,mel2,29)
